# PrettyHierarchy

Color your hierarchy objects in Unity!

Usage : Simply add a PrettyObject component to any of your GameObjects.

If the "Font" field is empty, the default font of your editor's preferences will be used.

Note : PrettyHierarchy is designed to match the UI changes that were introduced in the 2019.3 version.